# coding=utf-8
import scrapy


class ESFListSpider(scrapy.Spider):
    name = "esflist"
    allowed_domains = ["fang.com"]

    base_url = "http://esf.sh.fang.com/map/?mapmode=y&orderby=30&ecshop=ecshophouse&PageNo=$&a=ajaxSearch&city=sh&searchtype=loupan",

    start_urls = []

    for i in range(2, 5):
        start_urls.append(str(base_url).replace("$", str(i)))


    def parse(self, response):
        print "+++++++++++++++++++++++++ be called ++++++++++++++++"
        print len(response.url)
        print response.xpath("//a/@href")

        urlList = []

        infos = response.xpath("//a/@href").extract()
        print "-----size---->"
        print len(infos)
        print "-----size---->"
        for i in infos:
            i_str = str(i).encode("utf-8")
            if "esf" in i_str:
                url = i_str.replace('\\', '')
                urlList.append(url)
                print url
